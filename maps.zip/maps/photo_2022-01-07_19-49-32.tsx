<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="photo_2022-01-07_19-49-32" tilewidth="16" tileheight="16" tilecount="2" columns="2">
 <image source="photo_2022-01-07_19-49-32.jpg" width="38" height="24"/>
</tileset>
