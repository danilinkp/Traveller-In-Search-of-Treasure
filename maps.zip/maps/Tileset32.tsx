<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Tileset32" tilewidth="16" tileheight="16" tilecount="128" columns="16">
 <image source="Tileset32.png" width="256" height="128"/>
</tileset>
